
DROP PROCEDURE IF EXISTS busca_cliente;

DELIMITER !!
CREATE PROCEDURE busca_cliente(v_subcadena VARCHAR(20))
BEGIN
        
    CREATE TEMPORARY TABLE tabla_temporal_RFC
	SELECT CONCAT('RFC contiene "',v_subcadena,'"'),RFC FROM cliente
	WHERE RFC LIKE CONCAT('%',v_subcadena,'%');
	
 	CREATE TEMPORARY TABLE tabla_temporal_nombre
	SELECT CONCAT('nombre contiene "',v_subcadena,'"'),nombre FROM cliente
	WHERE nombre LIKE CONCAT('%',v_subcadena,'%');
	
    CREATE TEMPORARY TABLE tabla_temporal_domicilio	
	SELECT CONCAT('dimicilio contiene "',v_subcadena,'"'),domicilio FROM cliente
	WHERE domicilio LIKE CONCAT('%',v_subcadena,'%');
	
	CREATE TEMPORARY TABLE tabla_temporal_telefono	
	SELECT CONCAT('telefono contiene "',v_subcadena,'"'),telefono FROM cliente
	WHERE telefono LIKE CONCAT('%',v_subcadena,'%');
	
	CREATE TEMPORARY TABLE tabla_temporal
	SELECT 'Atributo','Valor' UNION
	SELECT * FROM tabla_temporal_RFC UNION
	SELECT * FROM tabla_temporal_nombre UNION
	SELECT * FROM tabla_temporal_domicilio UNION
	SELECT * FROM tabla_temporal_telefono;
	
	DELETE FROM tabla_temporal WHERE Atributo='Atributo';
	
END!!

DELIMITER ;
